package com.weekendkanban;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeekendKanbanApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeekendKanbanApplication.class, args);
	}

}
